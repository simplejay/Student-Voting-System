<div id="footer" align="center"><br/><b>&copy;Copyright 2012</b></div>
</body>
</html>