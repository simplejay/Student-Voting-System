<?php include "header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome, About page.</h3><br/>
<p>You may find us with below conact:
We are providing various voting system and management information system for various IT aspect.
Our experienced staff can make your IT idea into action.
</p>
<p>&nbsp;&nbsp;</p>
</div>
</div>
<?php include "footer.php";?>
